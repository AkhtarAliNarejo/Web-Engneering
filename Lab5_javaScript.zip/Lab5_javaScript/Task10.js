
function addKeyAndValue(obj,key,value){
    for(let k of obj){
        k[key] = value;
    }
    return obj;
}




const newObj = addKeyAndValue([{name: 'Elie'},{name: 'Tim'},{name: 'Elie'}], "isInstructor", true);

console.log(newObj);