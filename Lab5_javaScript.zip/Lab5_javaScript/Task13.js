function filterLetters(arrOfLetters,specificLetter){
    let arrOfOccurrence = [];
    for(let i = 0; i<arrOfLetters.length;i++){
        if(arrOfLetters[i] === specificLetter){
            arrOfOccurrence.push(arrOfLetters[i]);
        }
    }
    return arrOfOccurrence;
}


console.log(filterLetters(['a','s','f','s','s','d','f','s'],'s'));