function isOdd(num){
    if(num%2 !== 0){
        return true;
    }
    return false;
}

console.log(isOdd(2));