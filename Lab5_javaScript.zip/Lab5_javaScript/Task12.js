
function extractKey(obj,key){
    let arr = [];
    for(let k of obj){
        arr.push(k.name);
    }
    return arr;
}



let arrOfName  = extractKey([{name: "Elie", isInstructor:true},{name: "Tim", isInstructor:true},{name: 
    "Matt", isInstructor:true}], "name");


    console.log(arrOfName);