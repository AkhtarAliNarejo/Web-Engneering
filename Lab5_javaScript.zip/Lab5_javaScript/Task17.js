function removeVowels(str){
    let arr = [];
    var splitArr = str.toLowerCase().split("");
    splitArr.forEach(element => {
        if(element !== 'a'&& element !== 'e'&& element !== 'i'&& element !== 'o'&& element !== 'u'){
            arr.push(element);
        }
    });
    return arr;
}


console.log(removeVowels('Zulfiqar'))