function isPrime(num){
    let count = 0;
    for(i=1;i<=num;i++){
        if(num%i === 0){
            count += 1;
        }
    }
    if(count === 2){
        return true;
    }
    return false;
}


console.log(isPrime(17));