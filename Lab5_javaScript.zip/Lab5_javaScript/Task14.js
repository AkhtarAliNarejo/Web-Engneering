function filterKey(obj,key){
    let arrOfObject = [];
    let flag = false;
    for(let k of obj){
        for(let key in k){
            if(key === 'isHilarious'){
                flag = true;
            }
        }
        if(flag)
            arrOfObject.push(k);
        flag = false;
    }
    return arrOfObject;
}



let newArr = filterKey([{name: "Elie", isInstructor:true, isHilarious: false},{name:"Tim", isInstructor:true, 
isHilarious: true},{name: "Matt", isInstructor:true}], "isHilarious");


console.log(newArr);