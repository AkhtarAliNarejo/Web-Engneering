function countDown(val){
    setTimeout(()=>{
        if(val === 0){
            console.log('Done');
        }
       if(val > 0){
        console.log(val);
        return countDown(val-1);
       }
    },1000);
}
countDown(5);