function IndexGreaterThanTen(arr){
    return arr.find((n,index)=>{
        if(n>10){
            return index;
        }
    })
}

function indexEqualSeven(arr){
    return arr.find((n,index)=>{
        if(n === 7){
            return index;
        }
    })
}



function findIndex(arr,func){
    return func(arr);
}


console.log(findIndex([8,11,4,27], IndexGreaterThanTen));
console.log(findIndex([8,11,4,27], indexEqualSeven));