function printFirstAndLast(arr){
    let tempStr = '';
    for(let str of arr){
        tempStr = str[0]+str[str.length-1];
        console.log(tempStr);
        tempStr = '';
    }
}


printFirstAndLast(['awesome','example','of','forEach']);
