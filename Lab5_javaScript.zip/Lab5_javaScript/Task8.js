function specialMultiply(x,y=NaN){
    if(y!== NaN){
        return x*y;
    }
    return specialMultiply;
}

console.log(specialMultiply(3));