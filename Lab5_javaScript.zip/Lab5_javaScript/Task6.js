
function valGreaterThanTen(arr){
    return arr.find((n)=>{
        return n>=10;
    })
}

function valEqualFive(arr){
    return arr.find((n)=>{
        return n === 5;
    })
}


function find(val,func){
    return func(val);
}


console.log(find([8,11,4,27], valGreaterThanTen)); // 11 
console.log(find([8,11,4,27], valEqualFive));// undefined