function isEven(num){
    if(num%2 === 0){
        return true;
    }
    return false;
}

console.log(isEven(2));