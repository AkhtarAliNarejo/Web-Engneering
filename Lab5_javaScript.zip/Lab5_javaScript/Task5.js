function isEven(num){
    if(num%2 === 0){
        return true;
    }
    return false;
}


function isOdd(num){
    if(num%2 !== 0){
        return true;
    }
    return false;
}


function isPrime(num){
    let count = 0;
    for(i=1;i<=num;i++){
        if(num%i === 0){
            count += 1;
        }
    }
    if(count === 2){
        return true;
    }
    return false;
}


function numberFact(num,callBack){
    return callBack(num);
}


console.log(numberFact(21,isOdd));
console.log(numberFact(21,isEven));
console.log(numberFact(23,isPrime));